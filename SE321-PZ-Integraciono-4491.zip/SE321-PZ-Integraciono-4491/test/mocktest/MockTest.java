package mocktest;

import main.Karta;
import main.Rezervacija;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class MockTest {

    public MockTest() {
    }

    @BeforeClass
    public static void setUpClass() {

    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void firstTest() throws IllegalArgumentException {
        Karta k = new Karta("1234", "Beograd-Niš", "10.12.2022.", "18 časova", 3500);
        Rezervacija r = new Rezervacija();
        r.setImePrezime("Jovana Jovanović");
        r.setKarta(k);
        r.setTelefon("062346045");
        r.setBrKarata(2);
        double expected = 7000;
        double result = Rezervacija.cenaRezervacije(r);
        assertEquals(expected, result, 1.0);

    }

    @Test(expected = IllegalArgumentException.class)
    public void secondTest() throws IllegalArgumentException {
        Karta k = new Karta("1234", "Beograd-Niš", "10.12.2022.", "18 časova", 3500);
        Rezervacija r = new Rezervacija();
        r.setImePrezime("Jovana Jovanović");
        r.setKarta(k);
        r.setTelefon("062346045");
        r.setBrKarata(-2);
        double expected = 7000;
        double result = Rezervacija.cenaRezervacije(r);

    }
}

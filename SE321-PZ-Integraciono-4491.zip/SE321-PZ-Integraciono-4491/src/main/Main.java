package main;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HP
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Karta k = new Karta("1234", "Beograd-Niš", "10.12.2022.", "18 časova", 3500);

        Scanner sc = new Scanner(System.in);
        System.out.println("Rezervacija za kartu: " + k.toString());
        try {
            Rezervacija r = new Rezervacija();
            System.out.println("Unesite ime i prezime: ");
            String ime = sc.next();
            r.setImePrezime(ime);

            System.out.println("Unesite broj telefona: ");
            String broj = sc.next();
            r.setTelefon(broj);

            System.out.println("Unesite broj karata: ");
            int karte = sc.nextInt();
            r.setBrKarata(karte);
            r.setKarta(k);

            System.out.println("Ukupn iznos: " + Rezervacija.cenaRezervacije(r));

        } catch (IllegalArgumentException ex) {
            ex.getMessage();
        }
    }
}

package main;

/**
 *
 * @author HP
 */
public class Karta {

    private String sifra;
    private String destinacija;
    private String datumPolaska;
    private String vremePolaska;
    private double cena;

    public Karta() {
    }

    public Karta(String sifra, String destinacija, String datumPolaska, String vremePolaska, double cena) {
        this.sifra = sifra;
        this.destinacija = destinacija;
        this.datumPolaska = datumPolaska;
        this.vremePolaska = vremePolaska;
        this.cena = cena;
    }

    public String getSifra() {
        return sifra;
    }

    public void setSifra(String sifra) {
        this.sifra = sifra;
    }

    public String getDestinacija() {
        return destinacija;
    }

    public void setDestinacija(String destinacija) {
        this.destinacija = destinacija;
    }

    public String getDatumPolaska() {
        return datumPolaska;
    }

    public void setDatumPolaska(String datumPolaska) {
        this.datumPolaska = datumPolaska;
    }

    public String getVremePolaska() {
        return vremePolaska;
    }

    public void setVremePolaska(String vremePolaska) {
        this.vremePolaska = vremePolaska;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    @Override
    public String toString() {
        return "Karta{" + "sifra=" + sifra + ", destinacija=" + destinacija + ", datumPolaska=" + datumPolaska + ", vremePolaska=" + vremePolaska + ", cena=" + cena + '}';
    }

}

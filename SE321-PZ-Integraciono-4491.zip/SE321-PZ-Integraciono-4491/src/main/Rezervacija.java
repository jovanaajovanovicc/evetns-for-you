package main;

/**
 *
 * @author HP
 */
public class Rezervacija {

    private String imePrezime;
    private String telefon;
    private int brKarata;
    private Karta karta;

    public Rezervacija() throws IllegalArgumentException {
    }

    public Rezervacija(String imePrezime, String telefon, int brKarata, Karta karta) throws IllegalAccessException {
        this.imePrezime = imePrezime;
        this.telefon = telefon;
        this.brKarata = brKarata;
        this.karta = karta;

    }

    public String getImePrezime() {
        return imePrezime;
    }

    public void setImePrezime(String imePrezime) {
        this.imePrezime = imePrezime;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public int getBrKarata() {
        return brKarata;
    }

    public void setBrKarata(int brKarata) throws IllegalArgumentException {
        if (brKarata > 0) {
            this.brKarata = brKarata;
        } else {
            throw new IllegalArgumentException("Ne može negativna vrednost");
        }
    }

    public Karta getKarta() {
        return karta;
    }

    public void setKarta(Karta karta) {
        this.karta = karta;
    }

    @Override
    public String toString() {
        return "Rezervacija{" + "imePrezime=" + imePrezime + ", telefon=" + telefon + ", brKarata=" + brKarata + ", karta=" + karta + '}';
    }

    public static double cenaRezervacije(Rezervacija r) {

        return +r.getBrKarata() * r.getKarta().getCena();
    }

}
